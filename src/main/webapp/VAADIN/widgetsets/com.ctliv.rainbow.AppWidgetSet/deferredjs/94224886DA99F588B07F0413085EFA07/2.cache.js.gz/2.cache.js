$wnd.com_ctliv_rainbow_AppWidgetSet.runAsyncCallback2('jfb(1852,1,w7d);_.Xb=function pqc(){H4b((!z4b&&(z4b=new P4b),z4b),this.a.d)};A1d(xh)(2);\n//# sourceURL=com.ctliv.rainbow.AppWidgetSet-2.js\n')
